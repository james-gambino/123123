using Microsoft.AspNetCore.SignalR;
using Semantic.Backend.Runtime;
using Semantic.Contracts;

namespace Semantic.Backend.Realtime
{
    public sealed class WindowHub(
        WindowRuntime runtime,
        WindowStore windows,
        ILogger<WindowHub> logger) : Hub
    {
        public Task<WindowResponse> OpenAsync(string windowId, string route) =>
            RunAsync(
                nameof(OpenAsync),
                windowId,
                (window, _) => runtime.OpenAsync(route, window));

        public Task<WindowResponse> ExecuteAsync(
            string windowId,
            string pageId,
            string actionId) =>
            RunAsync(
                nameof(ExecuteAsync),
                windowId,
                (window, cancellationToken) => runtime.ExecuteAsync(
                    pageId,
                    actionId,
                    window,
                    cancellationToken));

        public Task<WindowResponse> ChangeAsync(
            string windowId,
            string pageId,
            FieldChange change) =>
            RunAsync(
                nameof(ChangeAsync),
                windowId,
                (window, cancellationToken) => runtime.ChangeAsync(
                    pageId,
                    change,
                    window,
                    cancellationToken));

        private async Task<WindowResponse> RunAsync(
            string operation,
            string windowId,
            Func<WindowSession, CancellationToken, Task<WindowSnapshot>> execute)
        {
            try
            {
                if (Context.Items.TryGetValue("window", out var existingWindow)
                    && !string.Equals((string)existingWindow!, windowId, StringComparison.Ordinal))
                    return new WindowResponse { Error = "SignalR-соединение уже связано с другим Window." };

                var window = windows.GetOrCreate(windowId, Context.UserIdentifier);
                Context.Items["window"] = window.Id;
                await window.Gate.WaitAsync(Context.ConnectionAborted);

                try
                {
                    var snapshot = await execute(window, Context.ConnectionAborted);
                    return new WindowResponse { Window = snapshot };
                }
                finally
                {
                    window.Touch(DateTime.UtcNow);
                    window.Gate.Release();
                }
            }
            catch (OperationCanceledException) when (Context.ConnectionAborted.IsCancellationRequested)
            {
                return new WindowResponse { Error = "Операция отменена." };
            }
            catch (Exception exception)
            {
                logger.LogError(
                    exception,
                    "Ошибка операции {Operation} для Window {WindowId}",
                    operation,
                    windowId);
                return new WindowResponse { Error = "Не удалось выполнить операцию." };
            }
        }
    }
}
