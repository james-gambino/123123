using System.Text.Json;

namespace Semantic.Backend.Runtime
{
    public sealed class WindowSession
    {
        private readonly Dictionary<Type, object> _models = [];
        private List<WindowPage> _pages = [];
        private long _lastActivityUtcTicks = DateTime.UtcNow.Ticks;

        public required string Id { get; init; }
        public string? UserId { get; init; }
        public DateTime LastActivityUtc => new(
            Interlocked.Read(ref _lastActivityUtcTicks),
            DateTimeKind.Utc);
        public SemaphoreSlim Gate { get; } = new(1, 1);

        public void Touch(DateTime utcNow) =>
            Interlocked.Exchange(ref _lastActivityUtcTicks, utcNow.Ticks);

        internal IReadOnlyList<WindowPage> Pages => _pages;

        internal void EnsureRoot(string route, PageRegistry registry)
        {
            var normalized = PageRegistry.Normalize(route);
            registry.Get(normalized);

            if (_pages.Count == 0)
            {
                _pages.Add(new WindowPage(Guid.NewGuid().ToString("N"), normalized));
                return;
            }

            if (!string.Equals(_pages[0].Route, normalized, StringComparison.OrdinalIgnoreCase))
                _pages = [new WindowPage(Guid.NewGuid().ToString("N"), normalized)];
        }

        internal WindowPage GetActivePage(string? pageId)
        {
            if (string.IsNullOrWhiteSpace(pageId))
                throw new InvalidOperationException("PageId не указан.");

            var active = _pages.LastOrDefault()
                ?? throw new InvalidOperationException("В окне нет активной Page.");

            return active.Id == pageId
                ? active
                : throw new InvalidOperationException($"Page '{pageId}' не является верхней Page окна.");
        }

        internal WindowNavigation CreateNavigation(PageRegistry registry) =>
            new(registry, _pages);

        internal void Apply(WindowNavigation navigation) =>
            _pages = [.. navigation.Pages];

        public object GetOrCreateModel(Type modelType, IServiceProvider services)
        {
            if (_models.TryGetValue(modelType, out var model)) return model;

            model = ActivatorUtilities.CreateInstance(services, modelType);
            _models[modelType] = model;
            return model;
        }

        public object CopyModel(Type modelType, IServiceProvider services)
        {
            var model = GetOrCreateModel(modelType, services);
            var json = JsonSerializer.Serialize(model, modelType);
            return JsonSerializer.Deserialize(json, modelType)
                ?? throw new InvalidOperationException($"Не удалось создать копию модели '{modelType.Name}'.");
        }

        public void ReplaceModel(Type modelType, object model)
        {
            if (!modelType.IsInstanceOfType(model))
                throw new ArgumentException("Тип модели не соответствует регистрации Page.", nameof(model));

            _models[modelType] = model;
        }
    }
}
