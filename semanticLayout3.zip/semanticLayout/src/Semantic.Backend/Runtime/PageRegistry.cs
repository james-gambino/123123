using Semantic.Backend.Composition;

namespace Semantic.Backend.Runtime
{
    internal sealed record PageRegistration(Type PageType, Type ModelType);

    public sealed class PageRegistry
    {
        private readonly Dictionary<string, PageRegistration> _pages =
            new(StringComparer.OrdinalIgnoreCase);
        private readonly Dictionary<Type, string> _routes = [];

        public void Register<TPage, TModel>(string route)
            where TPage : class, IPageDefinition
            where TModel : class
        {
            var normalized = Normalize(route);
            _pages[normalized] = new PageRegistration(typeof(TPage), typeof(TModel));
            _routes[typeof(TPage)] = normalized;
        }

        internal PageRegistration Get(string route) =>
            _pages.TryGetValue(Normalize(route), out var registration)
                ? registration
                : throw new KeyNotFoundException($"Page для маршрута '{route}' не зарегистрирована.");

        internal string Route<TPage>() where TPage : class, IPageDefinition =>
            _routes.TryGetValue(typeof(TPage), out var route)
                ? route
                : throw new KeyNotFoundException($"Page '{typeof(TPage).Name}' не зарегистрирована.");

        internal static string Normalize(string? route) =>
            "/" + (route ?? "demo").Trim('/').ToLowerInvariant();
    }
}
