namespace Semantic.Backend.Runtime
{
    public static class PageRegistrationExtensions
    {
        public static IServiceCollection AddUiPages(
            this IServiceCollection services,
            Action<PageRegistry> configure)
        {
            var registry = new PageRegistry();
            configure(registry);
            services.AddSingleton(registry);
            services.AddSingleton<WindowStore>();
            services.AddScoped<WindowRuntime>();
            return services;
        }
    }
}
