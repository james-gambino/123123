using Semantic.Backend.Composition;
using Semantic.Contracts;

namespace Semantic.Backend.Runtime
{
    public sealed class WindowRuntime(PageRegistry registry, IServiceProvider services)
    {
        public Task<WindowSnapshot> OpenAsync(string route, WindowSession window)
        {
            window.EnsureRoot(route, registry);
            return Task.FromResult(BuildSnapshot(window));
        }

        public async Task<WindowSnapshot> ExecuteAsync(
            string pageId,
            string actionId,
            WindowSession window,
            CancellationToken cancellationToken)
        {
            if (string.IsNullOrWhiteSpace(actionId))
                throw new InvalidOperationException("ActionId не указан.");

            var frame = window.GetActivePage(pageId);
            var registration = registry.Get(frame.Route);
            var model = window.CopyModel(registration.ModelType, services);
            var navigation = window.CreateNavigation(registry);
            var page = CreatePage(registration, model, navigation);

            if (!await page.TryExecuteAsync(actionId, cancellationToken))
                throw new InvalidOperationException($"Действие '{actionId}' не зарегистрировано.");

            window.ReplaceModel(registration.ModelType, model);
            window.Apply(navigation);
            return BuildSnapshot(window);
        }

        public async Task<WindowSnapshot> ChangeAsync(
            string pageId,
            FieldChange change,
            WindowSession window,
            CancellationToken cancellationToken)
        {
            var frame = window.GetActivePage(pageId);
            var registration = registry.Get(frame.Route);
            var model = window.CopyModel(registration.ModelType, services);
            var navigation = window.CreateNavigation(registry);
            var page = CreatePage(registration, model, navigation);

            if (!await page.TrySetAsync(change, cancellationToken))
                throw new InvalidOperationException($"Поле '{change.Name}' нельзя изменить.");

            window.ReplaceModel(registration.ModelType, model);
            window.Apply(navigation);
            return BuildSnapshot(window);
        }

        private IPageDefinition CreatePage(
            PageRegistration registration,
            object model,
            WindowNavigation navigation) =>
            (IPageDefinition)ActivatorUtilities.CreateInstance(
                services,
                registration.PageType,
                model,
                navigation);

        private WindowSnapshot BuildSnapshot(WindowSession window) => new()
        {
            Pages = window.Pages.Select(frame =>
            {
                var registration = registry.Get(frame.Route);
                var model = window.GetOrCreateModel(registration.ModelType, services);
                var navigation = window.CreateNavigation(registry);
                return CreatePage(registration, model, navigation).Build(frame.Id);
            }).ToArray()
        };
    }
}
