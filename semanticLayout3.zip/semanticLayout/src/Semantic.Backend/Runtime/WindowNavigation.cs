using Semantic.Backend.Composition;

namespace Semantic.Backend.Runtime
{
    internal sealed record WindowPage(string Id, string Route);

    public sealed class WindowNavigation
    {
        private readonly PageRegistry _registry;
        private readonly List<WindowPage> _pages;

        internal WindowNavigation(PageRegistry registry, IEnumerable<WindowPage> pages)
        {
            _registry = registry;
            _pages = [.. pages];
        }

        internal IReadOnlyList<WindowPage> Pages => _pages;

        public void Push<TPage>() where TPage : class, IPageDefinition =>
            Push(_registry.Route<TPage>());

        public void Push(string route)
        {
            var normalized = PageRegistry.Normalize(route);
            _registry.Get(normalized);
            _pages.Add(new WindowPage(Guid.NewGuid().ToString("N"), normalized));
        }

        public void Replace<TPage>() where TPage : class, IPageDefinition =>
            Replace(_registry.Route<TPage>());

        public void Replace(string route)
        {
            var normalized = PageRegistry.Normalize(route);
            _registry.Get(normalized);
            var replacement = new WindowPage(Guid.NewGuid().ToString("N"), normalized);

            if (_pages.Count == 0)
            {
                _pages.Add(replacement);
                return;
            }

            _pages[^1] = replacement;
        }

        public void Pop()
        {
            if (_pages.Count <= 1)
                throw new InvalidOperationException("Нельзя закрыть корневую Page окна.");

            _pages.RemoveAt(_pages.Count - 1);
        }
    }
}
