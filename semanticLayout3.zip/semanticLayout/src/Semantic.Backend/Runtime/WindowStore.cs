using Microsoft.Extensions.Configuration;

namespace Semantic.Backend.Runtime
{
    public sealed class WindowStore(IConfiguration configuration)
    {
        private readonly object _sync = new();
        private readonly Dictionary<string, WindowSession> _windows = [];
        private readonly TimeSpan _idleTimeout = TimeSpan.FromMinutes(
            Math.Max(1, configuration.GetValue("Windows:IdleTimeoutMinutes", 30)));
        private readonly TimeSpan _cleanupInterval = TimeSpan.FromMinutes(
            Math.Max(1, configuration.GetValue("Windows:CleanupIntervalMinutes", 1)));
        private DateTime _nextCleanupUtc;

        public WindowSession GetOrCreate(string windowId, string? userId)
        {
            if (string.IsNullOrWhiteSpace(windowId))
                throw new InvalidOperationException("WindowId не указан.");

            lock (_sync)
            {
                var utcNow = DateTime.UtcNow;
                RemoveExpired(utcNow);

                if (!_windows.TryGetValue(windowId, out var window))
                {
                    window = new WindowSession { Id = windowId, UserId = userId };
                    _windows.Add(windowId, window);
                }

                if (!string.Equals(window.UserId, userId, StringComparison.Ordinal))
                    throw new UnauthorizedAccessException("Window принадлежит другому пользователю.");

                window.Touch(utcNow);
                return window;
            }
        }

        private void RemoveExpired(DateTime utcNow)
        {
            if (utcNow < _nextCleanupUtc) return;
            _nextCleanupUtc = utcNow.Add(_cleanupInterval);

            foreach (var pair in _windows.ToArray())
            {
                var window = pair.Value;
                if (utcNow - window.LastActivityUtc < _idleTimeout || !window.Gate.Wait(0))
                    continue;

                try
                {
                    if (utcNow - window.LastActivityUtc >= _idleTimeout)
                        _windows.Remove(pair.Key);
                }
                finally
                {
                    window.Gate.Release();
                }
            }
        }
    }
}
