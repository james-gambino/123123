using Semantic.Backend.Realtime;
using Semantic.Backend.Runtime;
using Semantic.Backend.Views;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddUiPages(pages =>
{
    pages.Register<HomePage, Document>("/demo");
    pages.Register<DealDetailsPage, Document>("/demo/deal-details");
    pages.Register<QuickEditPage, Document>("/demo/quick-edit");
});

builder.Services.AddSignalR();
builder.Services.AddCors(options => options.AddDefaultPolicy(policy => policy
    .WithOrigins(builder.Configuration["FrontendOrigin"] ?? "http://localhost:5081")
    .AllowAnyHeader()
    .AllowAnyMethod()
    .AllowCredentials()));

var app = builder.Build();
app.UseCors();
app.MapHub<WindowHub>("/ui");
app.Run();
