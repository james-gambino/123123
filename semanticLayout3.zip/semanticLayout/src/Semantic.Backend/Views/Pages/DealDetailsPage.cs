using Semantic.Backend.Composition;
using Semantic.Backend.Runtime;
using Semantic.Contracts;

namespace Semantic.Backend.Views
{
    public sealed class DealDetailsPage : Page<Document>
    {
        public DealDetailsPage(Document model, WindowNavigation window) : base(model, window)
        {
            Body<Stack>(body =>
            {
                body.Grow();
                body.Area<AdaptiveMosaic>(grid =>
                {
                    grid.Area<Stack>("Основное", area =>
                    {
                        area.Edit(x => x.DealName).Label("Название");
                        area.Edit(x => x.Customer).Label("Компания");
                        area.Edit(x => x.Stage).Label("Этап");
                        area.Edit(x => x.Owner).Label("Ответственный");
                    }).Grow();

                    grid.Area<Stack>("Контакт", area =>
                    {
                        area.Edit(x => x.Contact).Label("Имя");
                        area.Edit(x => x.ContactRole).Label("Роль");
                        area.Edit(x => x.Email).Label("Email");
                        area.Edit(x => x.Phone).Label("Телефон");
                    });

                    grid.Area<BalancedCollection>("План сделки", area =>
                    {
                        area.Edit(x => x.NextStep).Label("Следующий шаг");
                        area.Edit(x => x.Delivery).Label("Срок поставки");
                        area.Read(x => x.Forecast).Label("Прогноз");
                        area.Read(x => x.Risk).Label("Риск");
                    }).Grow();
                });

                body.Area<InlineGroup>(actions =>
                    actions.Command("close")
                        .Label("Закрыть")
                        .Icon("close")
                        .Primary()
                        .Handle(CloseAsync));
            });
        }

        protected override string Title => "Полная карточка сделки";

        private Task CloseAsync(CancellationToken cancellationToken)
        {
            cancellationToken.ThrowIfCancellationRequested();
            Window.Pop();
            return Task.CompletedTask;
        }
    }
}
