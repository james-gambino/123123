using Semantic.Backend.Composition;
using Semantic.Backend.Runtime;
using Semantic.Contracts;

namespace Semantic.Backend.Views
{
    public sealed class HomePage : Page<Document>
    {
        public HomePage(Document model, WindowNavigation window) : base(model, window)
        {
            Body<Stack>(body =>
            {
                body.Area<InlineGroup>(header =>
                {
                    header.Read(x => x.Customer).Label("Клиент");
                    header.Read(x => x.Stage).Label("Этап");
                    header.Command("open-deal-details")
                        .Label("Полная карточка сделки")
                        .Icon("expand")
                        .Primary()
                        .Handle(OpenDealDetailsAsync);
                    header.Command("open-quick-edit")
                        .Label("Быстрое редактирование")
                        .Icon("window")
                        .Handle(OpenQuickEditAsync);
                });

                body.Area<AdaptiveMosaic>(grid =>
                {
                    grid.Area<Stack>("Сделка", area =>
                    {
                        area.Edit(x => x.DealName)
                            .Label("Название")
                            .Required()
                            .Handle(DealNameChangedAsync);
                        area.Edit(x => x.Customer).Label("Компания");
                        area.Edit(x => x.Owner).Label("Ответственный");
                        area.Edit(x => x.Stage).Label("Этап");
                    }).Grow();

                    grid.Area<InlineGroup>("Показатели", area =>
                    {
                        area.Read(x => x.Revenue).Label("Сумма");
                        area.Read(x => x.Probability).Label("Вероятность");
                        area.Read(x => x.Forecast).Label("Прогноз");
                        area.Read(x => x.Health).Label("Здоровье");
                    });

                    grid.Area<Stack>("Контакт", area =>
                    {
                        area.Edit(x => x.Contact).Label("Имя");
                        area.Edit(x => x.ContactRole).Label("Роль");
                        area.Edit(x => x.Email).Label("Email");
                        area.Edit(x => x.Phone).Label("Телефон");
                    });

                    grid.Area<Stack>("Следующий шаг", area =>
                    {
                        area.Edit(x => x.NextStep).Label("Действие");
                        area.Read(x => x.NextContact).Label("Контакт");
                    });

                    grid.Area<BalancedCollection>("Активности", area =>
                    {
                        area.Read(x => x.OpenTasks).Label("Задачи");
                        area.Read(x => x.LastActivity).Label("Последнее событие");
                    });

                    grid.Area<Overlay>(overlay =>
                    {
                        overlay.Area<Stack>("Поставка", area =>
                        {
                            area.Read(x => x.Product).Label("Решение");
                            area.Edit(x => x.Delivery).Label("Срок");
                            area.Read(x => x.Risk).Label("Риск");
                        });
                        overlay.Area<InlineGroup>(actions =>
                            actions.Command("mark-reviewed")
                                .Label("Проверено")
                                .Icon("check")
                                .Handle(MarkReviewedAsync));
                    });
                });
            });
        }

        protected override string Title => "Semantic CRM · адаптивная страница";

        private Task OpenDealDetailsAsync(CancellationToken cancellationToken)
        {
            cancellationToken.ThrowIfCancellationRequested();
            Window.Push<DealDetailsPage>();
            return Task.CompletedTask;
        }

        private Task OpenQuickEditAsync(CancellationToken cancellationToken)
        {
            cancellationToken.ThrowIfCancellationRequested();
            Window.Push<QuickEditPage>();
            return Task.CompletedTask;
        }

        private Task DealNameChangedAsync(CancellationToken cancellationToken)
        {
            cancellationToken.ThrowIfCancellationRequested();
            Model.LastActivity = "Только что · название сделки изменено";
            return Task.CompletedTask;
        }

        private Task MarkReviewedAsync(CancellationToken cancellationToken)
        {
            cancellationToken.ThrowIfCancellationRequested();
            Model.Health = "Проверено";
            Model.Risk = "Риски проверены ответственным";
            return Task.CompletedTask;
        }
    }
}
