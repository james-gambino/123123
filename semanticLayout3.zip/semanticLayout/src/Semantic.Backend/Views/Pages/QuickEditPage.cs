using Semantic.Backend.Composition;
using Semantic.Backend.Runtime;
using Semantic.Contracts;

namespace Semantic.Backend.Views
{
    public sealed class QuickEditPage : Page<Document>
    {
        public QuickEditPage(Document model, WindowNavigation window) : base(model, window)
        {
            Body<Stack>(body =>
            {
                body.Edit(x => x.DealName).Label("Название сделки");
                body.Edit(x => x.Owner).Label("Ответственный");
                body.Read(x => x.Stage).Label("Текущий этап");
                body.Area<InlineGroup>(actions =>
                    actions.Command("close")
                        .Label("Готово")
                        .Icon("check")
                        .Primary()
                        .Handle(CloseAsync));
            });
        }

        protected override string Title => "Быстрое редактирование";

        private Task CloseAsync(CancellationToken cancellationToken)
        {
            cancellationToken.ThrowIfCancellationRequested();
            Window.Pop();
            return Task.CompletedTask;
        }
    }
}
