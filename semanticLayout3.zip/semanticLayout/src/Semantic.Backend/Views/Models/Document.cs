namespace Semantic.Backend.Views
{
    public sealed class Document
    {
        public string DealName { get; set; } = "Lorem ipsum dolor sit amet";
        public string Customer { get; set; } = "Consectetur adipiscing elit";
        public string Stage { get; set; } = "Sed do eiusmod tempor incididunt";
        public string Owner { get; set; } = "Ut enim ad minim veniam";
        public string Revenue { get; set; } = "Quis nostrud exercitation";
        public string Probability { get; set; } = "Ullamco laboris";
        public string Forecast { get; set; } = "Nisi ut aliquip ex ea commodo";
        public string Health { get; set; } = "Duis aute irure dolor";
        public string Contact { get; set; } = "Reprehenderit in voluptate";
        public string ContactRole { get; set; } = "Velit esse cillum dolore";
        public string Email { get; set; } = "lorem.ipsum@example.com";
        public string Phone { get; set; } = "Excepteur sint occaecat";
        public string NextStep { get; set; } = "Cupidatat non proident, sunt in culpa qui officia deserunt";
        public string NextContact { get; set; } = "Mollit anim id est laborum";
        public string OpenTasks { get; set; } = "Lorem ipsum dolor sit amet";
        public string LastActivity { get; set; } = "Consectetur adipiscing elit, sed do eiusmod tempor";
        public string Product { get; set; } = "Incididunt ut labore et dolore magna aliqua";
        public string Delivery { get; set; } = "Ut enim ad minim veniam";
        public string Risk { get; set; } = "Quis nostrud exercitation ullamco laboris nisi ut aliquip";
    }
}
