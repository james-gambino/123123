using Semantic.Contracts;

namespace Semantic.Backend.Composition
{
    public sealed class FieldBuilder(
        PageNode node,
        string binding,
        Action<string, Func<CancellationToken, Task>> registerHandler)
    {
        private FieldSpec Field => node.Field!;

        public FieldBuilder Label(string label) { Field.Label = label; return this; }
        public FieldBuilder Required() { Field.Required = true; return this; }

        public FieldBuilder Handle(Func<CancellationToken, Task> handler)
        {
            registerHandler(binding, handler);
            return this;
        }

        public FieldBuilder State<TState>()
            where TState : INodeState
        {
            node.State = TState.Id;
            return this;
        }

        public FieldBuilder State<TState>(Func<string, bool> condition)
            where TState : INodeState
        {
            if (condition(Field.Value.GetString() ?? string.Empty)) node.State = TState.Id;
            return this;
        }
    }
}
