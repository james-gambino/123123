using Semantic.Contracts;

namespace Semantic.Backend.Composition
{
    public interface IPageDefinition
    {
        PageSnapshot Build(string id);
        Task<bool> TrySetAsync(FieldChange change, CancellationToken cancellationToken);
        Task<bool> TryExecuteAsync(string actionId, CancellationToken cancellationToken);
    }
}
