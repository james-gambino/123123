using System.Linq.Expressions;
using System.Text.Json;
using Semantic.Contracts;

namespace Semantic.Backend.Composition
{
    public sealed class ContainerBuilder<TModel> where TModel : class
    {
        private readonly TModel _model;
        private readonly PageNode _container;
        private readonly Action<string, Func<CancellationToken, Task>> _registerFieldHandler;
        private readonly Action<string, Func<CancellationToken, Task>> _registerCommandHandler;

        internal ContainerBuilder(
            TModel model,
            PageNode container,
            Action<string, Func<CancellationToken, Task>> registerFieldHandler,
            Action<string, Func<CancellationToken, Task>> registerCommandHandler)
        {
            _model = model;
            _container = container;
            _registerFieldHandler = registerFieldHandler;
            _registerCommandHandler = registerCommandHandler;
        }

        public ContainerBuilder<TModel> Area<TLayout>(Action<ContainerBuilder<TModel>> content)
            where TLayout : IContainerLayout =>
            Add(null, TLayout.Id, content);

        public ContainerBuilder<TModel> Area<TLayout>(
            string title,
            Action<ContainerBuilder<TModel>> content)
            where TLayout : IContainerLayout =>
            Add(title, TLayout.Id, content);

        public ContainerBuilder<TModel> Grow()
        {
            _container.Grow = true;
            return this;
        }

        public FieldBuilder Edit(Expression<Func<TModel, string>> selector) =>
            Field(selector, twoWay: true);

        public FieldBuilder Read(Expression<Func<TModel, string>> selector) =>
            Field(selector, twoWay: false);

        public CommandBuilder<TModel> Command(string actionId)
        {
            var command = new CommandSpec { ActionId = actionId };
            var node = new PageNode
            {
                Kind = CommandKind.Id,
                Command = command
            };
            _container.Children.Add(node);
            return new CommandBuilder<TModel>(_model, node, _registerCommandHandler);
        }

        public ContainerBuilder<TModel> State<TState>() where TState : INodeState
        {
            _container.State = TState.Id;
            return this;
        }

        public ContainerBuilder<TModel> State<TState>(Func<TModel, bool> condition)
            where TState : INodeState
        {
            if (condition(_model)) _container.State = TState.Id;
            return this;
        }

        private FieldBuilder Field(Expression<Func<TModel, string>> selector, bool twoWay)
        {
            var binding = MemberName(selector);
            var node = new PageNode
            {
                Kind = TextFieldKind.Id,
                Field = new FieldSpec
                {
                    Binding = binding,
                    Value = JsonSerializer.SerializeToElement(selector.Compile()(_model)),
                    TwoWay = twoWay
                }
            };
            _container.Children.Add(node);
            return new FieldBuilder(node, binding, _registerFieldHandler);
        }

        private ContainerBuilder<TModel> Add(
            string? title,
            string? layout,
            Action<ContainerBuilder<TModel>> content)
        {
            var child = new PageNode
            {
                Kind = ContainerKind.Id,
                Title = title,
                Layout = layout
            };
            _container.Children.Add(child);
            var builder = new ContainerBuilder<TModel>(
                _model,
                child,
                _registerFieldHandler,
                _registerCommandHandler);
            content(builder);
            return builder;
        }

        private static string MemberName(LambdaExpression expression)
        {
            var body = expression.Body is UnaryExpression unary ? unary.Operand : expression.Body;
            return body is MemberExpression member
                ? member.Member.Name
                : throw new ArgumentException("Expression должна указывать на свойство.");
        }
    }
}
