using System.Reflection;
using System.Text.Json;
using Semantic.Backend.Runtime;
using Semantic.Contracts;

namespace Semantic.Backend.Composition
{
    public abstract class Page<TModel> : IPageDefinition where TModel : class
    {
        private readonly TModel _model;
        private readonly WindowNavigation _window;
        private Action<ContainerBuilder<TModel>>? _body;
        private string? _bodyLayout;
        private HashSet<string> _editable = [];
        private Dictionary<string, List<Func<CancellationToken, Task>>> _fieldHandlers = [];
        private Dictionary<string, Func<CancellationToken, Task>> _commandHandlers = [];
        private bool _composed;

        protected Page(TModel model, WindowNavigation window)
        {
            _model = model;
            _window = window;
        }

        protected TModel Model => _model;
        protected WindowNavigation Window => _window;
        protected abstract string Title { get; }

        protected void Body<TLayout>(Action<ContainerBuilder<TModel>> content)
            where TLayout : IContainerLayout
        {
            if (_body is not null)
                throw new InvalidOperationException("Body страницы уже объявлен.");

            _body = content;
            _bodyLayout = TLayout.Id;
        }

        public PageSnapshot Build(string id)
        {
            var root = Compose();
            return new PageSnapshot
            {
                Id = id,
                Title = Title,
                Root = root
            };
        }

        public async Task<bool> TrySetAsync(
            FieldChange change,
            CancellationToken cancellationToken)
        {
            if (!_composed) Compose();
            if (!_editable.Contains(change.Name)) return false;

            var property = typeof(TModel).GetProperty(
                change.Name,
                BindingFlags.Instance | BindingFlags.Public);
            if (property?.CanWrite != true) return false;

            property.SetValue(_model, change.Value.Deserialize(property.PropertyType));

            if (_fieldHandlers.TryGetValue(change.Name, out var handlers))
            {
                foreach (var handler in handlers)
                    await handler(cancellationToken);
            }

            return true;
        }

        public async Task<bool> TryExecuteAsync(
            string actionId,
            CancellationToken cancellationToken)
        {
            if (!_composed) Compose();
            if (!_commandHandlers.TryGetValue(actionId, out var handler)) return false;

            await handler(cancellationToken);
            return true;
        }

        private PageNode Compose()
        {
            var body = _body
                ?? throw new InvalidOperationException("Body страницы не объявлен.");
            Dictionary<string, List<Func<CancellationToken, Task>>> fieldHandlers = [];
            Dictionary<string, Func<CancellationToken, Task>> commandHandlers = [];
            var root = new PageNode
            {
                Kind = ContainerKind.Id,
                Layout = _bodyLayout
            };
            var builder = new ContainerBuilder<TModel>(
                _model,
                root,
                (binding, handler) =>
                {
                    if (!fieldHandlers.TryGetValue(binding, out var registered))
                        fieldHandlers[binding] = registered = [];
                    registered.Add(handler);
                },
                (actionId, handler) =>
                {
                    if (!commandHandlers.TryAdd(actionId, handler))
                        throw new InvalidOperationException(
                            $"Обработчик действия '{actionId}' уже зарегистрирован.");
                });

            body(builder);
            AssignIds(root, "root");
            _editable = CollectEditable(root).ToHashSet(StringComparer.Ordinal);
            _fieldHandlers = fieldHandlers;
            _commandHandlers = commandHandlers;
            _composed = true;
            return root;
        }

        private static void AssignIds(PageNode node, string id)
        {
            node.Id = id;
            var occurrences = new Dictionary<string, int>(StringComparer.Ordinal);

            foreach (var child in node.Children)
            {
                var identity = Identity(child);
                occurrences.TryGetValue(identity, out var occurrence);
                occurrences[identity] = ++occurrence;
                var suffix = occurrence == 1 ? string.Empty : $"#{occurrence}";
                AssignIds(child, $"{id}/{identity}{suffix}");
            }
        }

        private static string Identity(PageNode node)
        {
            if (node.Field?.Binding is { Length: > 0 } binding)
                return $"field:{Segment(binding)}";
            if (node.Command?.ActionId is { Length: > 0 } actionId)
                return $"action:{Segment(actionId)}";

            var name = node.Title ?? node.Layout;
            return string.IsNullOrWhiteSpace(name)
                ? node.Kind
                : $"{node.Kind}:{Segment(name)}";
        }

        private static string Segment(string value) => Uri.EscapeDataString(value);

        private static IEnumerable<string> CollectEditable(PageNode node)
        {
            if (node.Field is { TwoWay: true, Binding: not null } field)
                yield return field.Binding;

            foreach (var child in node.Children)
            {
                foreach (var name in CollectEditable(child))
                    yield return name;
            }
        }
    }
}
