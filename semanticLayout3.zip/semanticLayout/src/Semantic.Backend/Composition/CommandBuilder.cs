using Semantic.Contracts;

namespace Semantic.Backend.Composition
{
    public sealed class CommandBuilder<TModel>(
        TModel model,
        PageNode node,
        Action<string, Func<CancellationToken, Task>> registerHandler)
        where TModel : class
    {
        private CommandSpec Command => node.Command!;

        public CommandBuilder<TModel> Label(string label) { Command.Label = label; return this; }
        public CommandBuilder<TModel> Icon(string icon) { Command.Icon = icon; return this; }
        public CommandBuilder<TModel> Primary() { Command.Primary = true; return this; }

        public CommandBuilder<TModel> Handle(Func<CancellationToken, Task> handler)
        {
            registerHandler(Command.ActionId, handler);
            return this;
        }

        public CommandBuilder<TModel> State<TState>() where TState : INodeState
        {
            node.State = TState.Id;
            return this;
        }

        public CommandBuilder<TModel> State<TState>(Func<TModel, bool> condition)
            where TState : INodeState
        {
            if (condition(model)) node.State = TState.Id;
            return this;
        }
    }
}
