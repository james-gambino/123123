using DevExpress.Blazor;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using Semantic.Frontend;
using Semantic.Frontend.Services;
using Semantic.Contracts;

var builder = WebAssemblyHostBuilder.CreateDefault(args);
builder.RootComponents.Add<App>("#app");
builder.RootComponents.Add<HeadOutlet>("head::after");
builder.Services.AddScoped<WindowIdProvider>();
builder.Services.AddScoped<WindowClient>();
builder.Services.AddScoped<ThemeState>();
var preset = new RendererPreset();
builder.Services.AddSingleton(preset);
builder.Services.AddSingleton(preset.Nodes);
builder.Services.AddSingleton(preset.States);
builder.Services.AddDevExpressBlazor();
await builder.Build().RunAsync();
