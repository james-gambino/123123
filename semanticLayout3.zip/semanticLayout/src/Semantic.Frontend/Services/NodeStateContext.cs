namespace Semantic.Frontend.Services
{
    public sealed class NodeStateContext
    {
        public string State { get; init; } = string.Empty;
        public string CssClass { get; init; } = string.Empty;
        public bool IsVisible { get; init; } = true;
        public bool IsEnabled { get; init; } = true;
    }
}
