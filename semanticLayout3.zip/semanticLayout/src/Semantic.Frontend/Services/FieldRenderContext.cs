using System.Text.Json;
using Microsoft.AspNetCore.Components;
using Semantic.Contracts;

namespace Semantic.Frontend.Services
{
    public sealed class FieldRenderContext
    {
        public required string NodeId { get; init; }
        public required FieldSpec Field { get; init; }
        public required NodeStateContext State { get; init; }
        public required JsonElement Value { get; init; }
        public required EventCallback<JsonElement> ValueChanged { get; init; }
    }
}
