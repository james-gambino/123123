namespace Semantic.Frontend.Services
{
    public sealed record ThemeOption(string Id, string Name, string CssClass);

    public sealed class ThemeState
    {
        public IReadOnlyList<ThemeOption> Options { get; } =
        [
            new("clean", "Clean", "theme-clean"),
            new("graphite", "Graphite", "theme-graphite"),
            new("forest", "Forest", "theme-forest"),
            new("sunset", "Sunset", "theme-sunset")
        ];

        public ThemeOption Current { get; private set; }

        public event Action? Changed;

        public ThemeState() => Current = Options[0];

        public void Select(string? id)
        {
            var selected = Options.FirstOrDefault(option => option.Id == id);
            if (selected is null || selected == Current) return;

            Current = selected;
            Changed?.Invoke();
        }
    }
}
