using Microsoft.AspNetCore.Components;
using Semantic.Contracts;

namespace Semantic.Frontend.Services
{
    public sealed class NodeRendererRegistry
    {
        private readonly Dictionary<string, Type> _renderers = [];

        public NodeRendererRegistry Map<TKind, TComponent>()
            where TKind : INodeKind
            where TComponent : IComponent
        {
            _renderers[TKind.Id] = typeof(TComponent);
            return this;
        }

        public Type Resolve(string kind) => _renderers.TryGetValue(kind, out var renderer)
            ? renderer
            : throw new KeyNotFoundException($"Renderer для вида узла '{kind}' не зарегистрирован в preset.");
    }
}
