using Semantic.Contracts;

namespace Semantic.Frontend.Services
{
    public sealed class NodeStateRegistry
    {
        private readonly Dictionary<string, NodeStateDefinition> _definitions = [];

        public NodeStateRegistry Map<TState>(
            bool isVisible = true,
            bool isEnabled = true)
            where TState : INodeState
        {
            return Map<TState>(new NodeStateDefinition
            {
                CssClass = DefaultCssClass(TState.Id),
                IsVisible = isVisible,
                IsEnabled = isEnabled
            });
        }

        public NodeStateRegistry Map<TState>(NodeStateDefinition definition)
            where TState : INodeState
        {
            _definitions[TState.Id] = definition;
            return this;
        }

        public NodeStateContext Resolve(string? state, NodeStateContext? parent = null)
        {
            var stateId = state ?? Normal.Id;
            if (!_definitions.TryGetValue(stateId, out var definition))
                throw new KeyNotFoundException($"Состояние '{stateId}' не зарегистрировано в preset.");

            return new NodeStateContext
            {
                State = stateId,
                CssClass = definition.CssClass,
                IsVisible = (parent?.IsVisible ?? true) && definition.IsVisible,
                IsEnabled = (parent?.IsEnabled ?? true) && definition.IsEnabled
            };
        }

        private static string DefaultCssClass(string stateId) => stateId.Replace('.', '-');
    }
}
