namespace Semantic.Frontend.Services
{
    public sealed class NodeStateDefinition
    {
        public string CssClass { get; init; } = string.Empty;
        public bool IsVisible { get; init; } = true;
        public bool IsEnabled { get; init; } = true;
    }
}
