namespace Semantic.Frontend.Services
{
    public sealed class WindowIdProvider
    {
        public string Id { get; } = Guid.NewGuid().ToString("N");
    }
}
