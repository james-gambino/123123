using Microsoft.AspNetCore.SignalR.Client;
using Semantic.Contracts;

namespace Semantic.Frontend.Services
{
    public sealed class WindowClient : IAsyncDisposable
    {
        private readonly HubConnection _hub;
        private readonly WindowIdProvider _window;

        public WindowClient(IConfiguration configuration, WindowIdProvider window)
        {
            _window = window;
            var backend = (configuration["BackendUrl"] ?? "http://localhost:5080").TrimEnd('/');
            _hub = new HubConnectionBuilder()
                .WithUrl($"{backend}/ui")
                .WithAutomaticReconnect()
                .Build();
        }

        public event Action<WindowResponse>? Received;

        public Task<WindowResponse> OpenAsync(string route) =>
            InvokeAsync(nameof(OpenAsync), _window.Id, route);

        public async Task<WindowResponse> ExecuteAsync(string pageId, string actionId)
        {
            var response = await InvokeAsync(nameof(ExecuteAsync), _window.Id, pageId, actionId);
            Received?.Invoke(response);
            return response;
        }

        public async Task<WindowResponse> ChangeAsync(string pageId, FieldChange change)
        {
            var response = await InvokeAsync(nameof(ChangeAsync), _window.Id, pageId, change);
            Received?.Invoke(response);
            return response;
        }

        private async Task<WindowResponse> InvokeAsync(string method, params object?[] arguments)
        {
            if (_hub.State == HubConnectionState.Disconnected)
                await _hub.StartAsync();

            return await _hub.InvokeCoreAsync<WindowResponse>(method, arguments);
        }

        public ValueTask DisposeAsync() => _hub.DisposeAsync();
    }
}
