using Semantic.Contracts;
using Semantic.Frontend.Components;

namespace Semantic.Frontend.Services
{
    public sealed class RendererPreset
    {
        public NodeRendererRegistry Nodes { get; } = new();
        public NodeStateRegistry States { get; } = new();

        public RendererPreset()
        {
            Nodes
                .Map<ContainerKind, ContainerRenderer>()
                .Map<CommandKind, CommandRenderer>()
                .Map<TextFieldKind, FieldRenderer>();

            States
                .Map<Normal>()
                .Map<Disabled>(isEnabled: false)
                .Map<Hidden>(isVisible: false, isEnabled: false);
        }
    }
}
