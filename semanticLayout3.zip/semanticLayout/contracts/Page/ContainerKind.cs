namespace Semantic.Contracts
{
    public sealed class ContainerKind : INodeKind
    {
        public static string Id => "node.container";
    }
}
