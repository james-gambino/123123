namespace Semantic.Contracts
{
    public interface INodeKind
    {
        static abstract string Id { get; }
    }
}
