namespace Semantic.Contracts
{
    public sealed class WindowSnapshot
    {
        public IReadOnlyList<PageSnapshot> Pages { get; init; } = [];
    }
}
