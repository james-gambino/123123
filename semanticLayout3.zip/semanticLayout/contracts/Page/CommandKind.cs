namespace Semantic.Contracts
{
    public sealed class CommandKind : INodeKind
    {
        public static string Id => "node.command";
    }
}
