using System.Text.Json;

namespace Semantic.Contracts
{
    public sealed class FieldSpec
    {
        public string? Binding { get; set; }
        public string? Label { get; set; }
        public JsonElement Value { get; set; }
        public bool TwoWay { get; set; }
        public bool Required { get; set; }
    }
}
