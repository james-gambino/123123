namespace Semantic.Contracts
{
    public sealed class CommandSpec
    {
        public required string ActionId { get; set; }
        public string? Label { get; set; }
        public string? Icon { get; set; }
        public bool Primary { get; set; }
    }
}
