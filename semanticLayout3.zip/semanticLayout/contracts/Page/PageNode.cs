namespace Semantic.Contracts
{
    public sealed class PageNode
    {
        public required string Kind { get; set; }
        public string? Id { get; set; }
        public string? Title { get; set; }
        public string? Layout { get; set; }
        public bool Grow { get; set; }
        public string? State { get; set; }
        public FieldSpec? Field { get; set; }
        public CommandSpec? Command { get; set; }
        public List<PageNode> Children { get; set; } = [];
    }
}
