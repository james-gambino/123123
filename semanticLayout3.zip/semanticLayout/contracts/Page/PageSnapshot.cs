namespace Semantic.Contracts
{
    public sealed class PageSnapshot
    {
        public required string Id { get; init; }
        public required string Title { get; init; }
        public required PageNode Root { get; init; }
    }
}
