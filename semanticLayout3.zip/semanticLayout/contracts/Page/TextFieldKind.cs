namespace Semantic.Contracts
{
    public sealed class TextFieldKind : INodeKind
    {
        public static string Id => "node.text-field";
    }
}
