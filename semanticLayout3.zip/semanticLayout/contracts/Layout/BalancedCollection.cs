namespace Semantic.Contracts
{
    public sealed class BalancedCollection : IContainerLayout
    {
        public static string Id => "layout.balanced-collection";
    }
}
