namespace Semantic.Contracts
{

    public sealed class Stack : IContainerLayout
    {
        public static string Id => "layout.stack";
    }
}
