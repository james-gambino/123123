namespace Semantic.Contracts
{
    public sealed class InlineGroup : IContainerLayout
    {
        public static string Id => "layout.inline-group";
    }
}
