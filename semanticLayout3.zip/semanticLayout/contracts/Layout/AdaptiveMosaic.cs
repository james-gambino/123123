namespace Semantic.Contracts
{
    public sealed class AdaptiveMosaic : IContainerLayout
    {
        public static string Id => "layout.adaptive-mosaic";
    }
}
