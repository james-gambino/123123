namespace Semantic.Contracts
{
    public sealed class Overlay : IContainerLayout
    {
        public static string Id => "layout.overlay";
    }
}
