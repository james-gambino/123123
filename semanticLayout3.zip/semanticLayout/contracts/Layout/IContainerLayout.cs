namespace Semantic.Contracts
{
    public interface IContainerLayout
    {
        static abstract string Id { get; }
    }
}
