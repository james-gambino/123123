namespace Semantic.Contracts
{
    public sealed class Normal : INodeState
    {
        public static string Id => "state.normal";
    }
}
