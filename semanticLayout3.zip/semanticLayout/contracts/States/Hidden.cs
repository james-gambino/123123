namespace Semantic.Contracts
{
    public sealed class Hidden : INodeState
    {
        public static string Id => "state.hidden";
    }
}
