namespace Semantic.Contracts
{
    public sealed class Disabled : INodeState
    {
        public static string Id => "state.disabled";
    }
}
