namespace Semantic.Contracts
{
    public interface INodeState
    {
        static abstract string Id { get; }
    }
}
