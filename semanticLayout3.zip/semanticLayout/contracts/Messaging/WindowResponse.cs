namespace Semantic.Contracts
{
    public sealed class WindowResponse
    {
        public WindowSnapshot? Window { get; init; }
        public string? Error { get; init; }
    }
}
