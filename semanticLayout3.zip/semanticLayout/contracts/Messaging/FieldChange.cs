using System.Text.Json;

namespace Semantic.Contracts
{
    public sealed record FieldChange(string Name, JsonElement Value);
}
