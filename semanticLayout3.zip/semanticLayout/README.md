# Semantic

Минимальный server-driven UI для CRM на Blazor WebAssembly и SignalR. Backend
хранит состояние отдельного окна браузера и строит семантическое дерево;
frontend интерпретирует его, а Blazor выполняет обычный RenderTree/DOM diff.

Главная цель API — позволить разработчику описывать страницу через понятные
CRM-понятия, не работая с HTML и CSS:

```csharp
Body<Stack>(body =>
{
    body.Area<InlineGroup>(header =>
    {
        header.Read(x => x.Customer).Label("Клиент");
        header.Command("open-details")
            .Label("Открыть сделку")
            .Handle(OpenDetailsAsync);
    });

    body.Area<AdaptiveMosaic>(mosaic =>
    {
        mosaic.Area<Stack>("Сделка", area =>
        {
            area.Edit(x => x.DealName).Label("Название").Required();
            area.Edit(x => x.Owner).Label("Ответственный");
        }).Grow();

        mosaic.Area<InlineGroup>("Показатели", area =>
        {
            area.Read(x => x.Revenue).Label("Сумма");
            area.Read(x => x.Probability).Label("Вероятность");
        });
    });
});
```

## Модель

Во всём стеке используется один словарь:

- `WindowSnapshot` — снимок окна со стеком страниц;
- `PageSnapshot` — одна страница: `Id`, `Title`, `Root`;
- `PageNode` — универсальный узел дерева;
- `ContainerKind`, `TextFieldKind`, `CommandKind` — виды узлов;
- `FieldSpec`, `CommandSpec` — данные специализированных узлов;
- `Stack`, `InlineGroup`, `BalancedCollection`, `AdaptiveMosaic`, `Overlay` —
  способы размещения непосредственных детей контейнера;
- `Normal`, `Disabled`, `Hidden` — состояния текущего узла.

У расширений есть ровно три категории:

```csharp
public interface INodeKind
{
    static abstract string Id { get; }
}

public interface IContainerLayout
{
    static abstract string Id { get; }
}

public interface INodeState
{
    static abstract string Id { get; }
}
```

`Kind` отвечает на вопрос «что это за узел», `Layout` — «как контейнер размещает
своих детей», `State` — «доступен и видим ли текущий узел». Данные всех трёх
категорий лежат в одном `PageNode`, но интерфейсы разделены, потому что у них
разные правила применения.

`Grow()` — единственная подсказка размещению текущего узла у родителя. Сейчас её
интерпретирует `AdaptiveMosaic`: обычная область занимает одну колонку, а
`Grow`-область — две на широком экране. Это не роль и не стиль оформления.

## Где проходит граница

Backend использует типизированный DSL (`Body<Stack>`, `Area<AdaptiveMosaic>`) и
передаёт только общие контракты из `Semantic.Contracts`. В снимке нет CSS,
Blazor-компонентов или delegates.

Frontend содержит две явные таблицы интерпретации:

```csharp
Nodes
    .Map<ContainerKind, ContainerRenderer>()
    .Map<CommandKind, CommandRenderer>()
    .Map<TextFieldKind, FieldRenderer>();

States
    .Map<Normal>()
    .Map<Disabled>(isEnabled: false)
    .Map<Hidden>(isVisible: false, isEnabled: false);
```

Для layouts отдельной таблицы C#-классов нет. `ContainerRenderer` пишет общий
`Layout` в `data-layout`, а CSS применяет правила к стабильным идентификаторам
вида `layout.stack`. Благодаря этому один layout не требует пары пустых классов
на frontend.

## Окна и страницы

Page и модальное окно — одна сущность. `WindowSession` хранит стек страниц:

- `Window.Push<TPage>()` добавляет страницу поверх текущей;
- `Window.Pop()` закрывает верхнюю страницу;
- `Window.Replace<TPage>()` заменяет верхнюю страницу.

`WindowHost` показывает первую страницу как основу, последующие — как слои с
backdrop. Корневой `Grow()` сообщает host, что слою нужно расширенное
пространство. Специальных `Modal`, `DialogSize` и UI-состояний в модели документа
нет.

## Поток обновления

```text
TextField / SemanticButton
    → WindowClient.ChangeAsync / ExecuteAsync
    → WindowHub
    → WindowRuntime
    → handler над копией модели
    → WindowSnapshot
    → PageNodeRenderer
    → стандартный Blazor render diff
```

SignalR API состоит из трёх прямых операций: `OpenAsync`, `ChangeAsync` и
`ExecuteAsync`. Универсального tagged-union `Request/Command` нет. Изменение
сначала выполняется над глубокой копией модели и коммитится в `WindowSession`
только после успешного handler-а.

У каждого слоя собственный `PageId`, поэтому событие адресуется только верхней
странице. Стабильные ID узлов строятся из binding, `ActionId`, layout и заголовка;
`@key` помогает Blazor сохранять экземпляры компонентов при получении полного
снимка.

## Структура проектов

```text
Semantic.Contracts          общие DTO и три категории расширения
Semantic.Backend
  Composition               Page и builders декларативного DSL
  Runtime                   registry, window state, navigation, execution
  Realtime                  тонкий SignalR WindowHub
Semantic.Frontend
  Components                интерпретаторы узлов и UI primitives
  Services                  registries, WindowClient, theme
  Pages/WindowHost          размещение стека Page
```

## Запуск

```bash
dotnet run --project src/Semantic.Backend
dotnet run --project src/Semantic.Frontend
```

- demo: <http://localhost:5081/>;
- backend SignalR: <http://localhost:5080/ui>.

DevExpress закреплён на версии 25.2.9. Без локальной лицензии библиотека выводит
evaluation-предупреждения DX1000 и DX1001.
